$(document).ready(function() {
    // API Provider selection handler
    $('#apiProvider').change(function() {
        const provider = $(this).val();
        
        if (provider === 'groq') {
            $('#groqConfig').removeClass('d-none').addClass('show');
            $('#huggingfaceConfig').removeClass('show').addClass('d-none');
        } else if (provider === 'huggingface') {
            $('#huggingfaceConfig').removeClass('d-none').addClass('show');
            $('#groqConfig').removeClass('show').addClass('d-none');
        }
    });
    
    // Configuration form submission
    $('#configForm').submit(function(e) {
        e.preventDefault();
        
        const formData = {
            api_provider: $('#apiProvider').val(),
            groq_api_key: $('#groqApiKey').val(),
            huggingface_api_key: $('#huggingfaceApiKey').val(),
            model_name: $('#modelName').val()
        };
        
        $.ajax({
            url: '/api/config',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(formData),
            success: function(response) {
                showAlert('Configuration saved successfully!', 'success');
            },
            error: function() {
                showAlert('Error saving configuration. Please try again.', 'danger');
            }
        });
    });
    
    // Test API button handler
    $('#testBtn').click(function() {
        const provider = $('#apiProvider').val();
        const testData = {
            api_provider: provider
        };
        
        if (provider === 'groq') {
            testData.groq_api_key = $('#groqApiKey').val();
            testData.model_name = $('#modelName').val();
            
            if (!testData.groq_api_key) {
                showAlert('Please enter your Groq API key first.', 'warning');
                return;
            }
        } else if (provider === 'huggingface') {
            testData.huggingface_api_key = $('#huggingfaceApiKey').val();
            
            if (!testData.huggingface_api_key) {
                showAlert('Please enter your Hugging Face API key first.', 'warning');
                return;
            }
        }
        
        const $btn = $(this);
        const originalText = $btn.html();
        
        $btn.prop('disabled', true).html('<i data-feather="loader" class="me-2"></i>Testing...');
        feather.replace();
        
        $.ajax({
            url: '/api/test',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(testData),
            success: function(response) {
                if (response.success) {
                    showTestResult('API connection successful!', 'success');
                } else {
                    showTestResult(`API test failed: ${response.message}`, 'danger');
                }
            },
            error: function() {
                showTestResult('Network error occurred during API test.', 'danger');
            },
            complete: function() {
                $btn.prop('disabled', false).html(originalText);
                feather.replace();
            }
        });
    });
    
    function showAlert(message, type) {
        const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                <i data-feather="${type === 'success' ? 'check-circle' : type === 'danger' ? 'alert-circle' : 'info'}"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        // Remove existing alerts
        $('.alert').remove();
        
        // Add new alert after the form
        $('#configForm').after(alertHtml);
        feather.replace();
        
        // Auto-remove after 5 seconds
        setTimeout(function() {
            $('.alert').fadeOut();
        }, 5000);
    }
    
    function showTestResult(message, type) {
        const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
        const iconClass = type === 'success' ? 'check-circle' : 'alert-circle';
        
        $('#testAlert')
            .removeClass('alert-success alert-danger')
            .addClass(alertClass)
            .html(`<i data-feather="${iconClass}" class="me-2"></i>${message}`);
        
        $('#testResults').show();
        feather.replace();
        
        // Auto-hide after 10 seconds
        setTimeout(function() {
            $('#testResults').fadeOut();
        }, 10000);
    }
});
