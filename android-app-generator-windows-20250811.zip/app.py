import os
import json
import logging
import requests
import zipfile
import shutil
import webbrowser
from threading import Timer
from flask import Flask, render_template, request, jsonify, send_file, flash, redirect, url_for
from werkzeug.utils import secure_filename
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "android-app-generator-secret-key")

# Configuration
UPLOAD_FOLDER = 'uploads'
GENERATED_FOLDER = 'generated_apps'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Create necessary directories
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(GENERATED_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_config():
    """Load API configuration from config.json"""
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {
            'api_provider': 'groq',
            'groq_api_key': '',
            'huggingface_api_key': '',
            'model_name': 'llama3-8b-8192'
        }

def save_config(config):
    """Save API configuration to config.json"""
    with open('config.json', 'w') as f:
        json.dump(config, f, indent=2)

def test_groq_api(api_key, model_name):
    """Test Groq API connection"""
    try:
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        data = {
            'messages': [{'role': 'user', 'content': 'Hello'}],
            'model': model_name,
            'max_tokens': 10
        }
        response = requests.post('https://api.groq.com/openai/v1/chat/completions', 
                               headers=headers, json=data, timeout=10)
        return response.status_code == 200, response.text
    except Exception as e:
        return False, str(e)

def test_huggingface_api(api_key):
    """Test Hugging Face API connection"""
    try:
        headers = {'Authorization': f'Bearer {api_key}'}
        response = requests.get('https://huggingface.co/api/whoami', 
                              headers=headers, timeout=10)
        return response.status_code == 200, response.text
    except Exception as e:
        return False, str(e)

def generate_with_groq(prompt, api_key, model_name):
    """Generate Android app code using Groq API"""
    try:
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        system_prompt = """You are an expert Android developer. Generate a complete Android app based on the user's request. 
        Respond with a JSON object containing:
        - app_name: The application name
        - package_name: Java package name (com.example.appname format)
        - main_activity_code: Complete MainActivity.java code
        - layout_xml: Complete activity_main.xml layout
        - manifest_additions: Any special manifest permissions or features needed
        - description: Brief description of what the app does
        
        Make the app functional and complete."""
        
        data = {
            'messages': [
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': prompt}
            ],
            'model': model_name,
            'max_tokens': 4000,
            'temperature': 0.7
        }
        
        response = requests.post('https://api.groq.com/openai/v1/chat/completions', 
                               headers=headers, json=data, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            content = result['choices'][0]['message']['content']
            
            # Try to extract JSON from the response
            try:
                # Find JSON block in the response
                start_idx = content.find('{')
                end_idx = content.rfind('}') + 1
                if start_idx != -1 and end_idx != 0:
                    json_str = content[start_idx:end_idx]
                    return True, json.loads(json_str)
                else:
                    # Fallback: create basic structure
                    return True, {
                        'app_name': 'GeneratedApp',
                        'package_name': 'com.example.generatedapp',
                        'main_activity_code': content,
                        'layout_xml': '<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent"><TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="Hello World!" /></LinearLayout>',
                        'manifest_additions': '',
                        'description': 'Generated Android app'
                    }
            except json.JSONDecodeError:
                # Fallback for non-JSON response
                return True, {
                    'app_name': 'GeneratedApp',
                    'package_name': 'com.example.generatedapp',
                    'main_activity_code': content,
                    'layout_xml': '<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent"><TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="Hello World!" /></LinearLayout>',
                    'manifest_additions': '',
                    'description': 'Generated Android app'
                }
        else:
            return False, f"API Error: {response.status_code} - {response.text}"
            
    except Exception as e:
        return False, str(e)

def generate_with_huggingface(prompt, api_key):
    """Generate Android app code using Hugging Face API"""
    try:
        headers = {'Authorization': f'Bearer {api_key}'}
        
        # Use a code generation model
        api_url = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium"
        
        data = {
            'inputs': f"Generate Android app code for: {prompt}",
            'parameters': {
                'max_length': 2000,
                'temperature': 0.7
            }
        }
        
        response = requests.post(api_url, headers=headers, json=data, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            content = result[0]['generated_text'] if isinstance(result, list) else str(result)
            
            return True, {
                'app_name': 'GeneratedApp',
                'package_name': 'com.example.generatedapp',
                'main_activity_code': content,
                'layout_xml': '<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent"><TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="Hello World!" /></LinearLayout>',
                'manifest_additions': '',
                'description': 'Generated Android app'
            }
        else:
            return False, f"API Error: {response.status_code} - {response.text}"
            
    except Exception as e:
        return False, str(e)

def create_android_project(app_data, image_path=None):
    """Create complete Android Studio project structure"""
    app_name = app_data.get('app_name', 'GeneratedApp')
    package_name = app_data.get('package_name', 'com.example.generatedapp')
    
    # Clean app name for folder
    clean_app_name = "".join(c for c in app_name if c.isalnum() or c in (' ', '_')).strip().replace(' ', '_')
    
    # Create project directory
    project_dir = os.path.join(GENERATED_FOLDER, clean_app_name)
    if os.path.exists(project_dir):
        shutil.rmtree(project_dir)
    
    # Create directory structure
    os.makedirs(project_dir)
    os.makedirs(os.path.join(project_dir, 'app', 'src', 'main', 'java', *package_name.split('.')))
    os.makedirs(os.path.join(project_dir, 'app', 'src', 'main', 'res', 'layout'))
    os.makedirs(os.path.join(project_dir, 'app', 'src', 'main', 'res', 'values'))
    os.makedirs(os.path.join(project_dir, 'app', 'src', 'main', 'res', 'mipmap-hdpi'))
    os.makedirs(os.path.join(project_dir, 'app', 'src', 'main', 'res', 'mipmap-mdpi'))
    os.makedirs(os.path.join(project_dir, 'app', 'src', 'main', 'res', 'mipmap-xhdpi'))
    os.makedirs(os.path.join(project_dir, 'app', 'src', 'main', 'res', 'mipmap-xxhdpi'))
    os.makedirs(os.path.join(project_dir, 'app', 'src', 'main', 'res', 'mipmap-xxxhdpi'))
    
    # Load templates and replace placeholders
    templates_dir = 'android_templates'
    
    # MainActivity.java
    with open(os.path.join(templates_dir, 'MainActivity.java'), 'r') as f:
        main_activity = f.read()
    
    # Use generated code if available, otherwise use template
    if 'main_activity_code' in app_data and app_data['main_activity_code'].strip():
        main_activity_content = app_data['main_activity_code']
        # Ensure package declaration
        if not main_activity_content.startswith('package'):
            main_activity_content = f"package {package_name};\n\n" + main_activity_content
    else:
        main_activity_content = main_activity.replace('{{PACKAGE_NAME}}', package_name).replace('{{APP_NAME}}', app_name)
    
    with open(os.path.join(project_dir, 'app', 'src', 'main', 'java', *package_name.split('.'), 'MainActivity.java'), 'w') as f:
        f.write(main_activity_content)
    
    # activity_main.xml
    with open(os.path.join(templates_dir, 'activity_main.xml'), 'r') as f:
        layout = f.read()
    
    # Use generated layout if available, otherwise use template
    if 'layout_xml' in app_data and app_data['layout_xml'].strip():
        layout_content = app_data['layout_xml']
    else:
        layout_content = layout.replace('{{APP_NAME}}', app_name)
    
    with open(os.path.join(project_dir, 'app', 'src', 'main', 'res', 'layout', 'activity_main.xml'), 'w') as f:
        f.write(layout_content)
    
    # AndroidManifest.xml
    with open(os.path.join(templates_dir, 'AndroidManifest.xml'), 'r') as f:
        manifest = f.read()
    
    manifest_additions = app_data.get('manifest_additions', '')
    manifest_content = manifest.replace('{{PACKAGE_NAME}}', package_name).replace('{{APP_NAME}}', app_name).replace('{{MANIFEST_ADDITIONS}}', manifest_additions)
    
    with open(os.path.join(project_dir, 'app', 'src', 'main', 'AndroidManifest.xml'), 'w') as f:
        f.write(manifest_content)
    
    # build.gradle (project level)
    with open(os.path.join(templates_dir, 'build.gradle'), 'r') as f:
        build_gradle = f.read()
    
    with open(os.path.join(project_dir, 'build.gradle'), 'w') as f:
        f.write(build_gradle)
    
    # build.gradle (app level)
    with open(os.path.join(templates_dir, 'app_build.gradle'), 'r') as f:
        app_build_gradle = f.read()
    
    app_build_content = app_build_gradle.replace('{{PACKAGE_NAME}}', package_name)
    
    with open(os.path.join(project_dir, 'app', 'build.gradle'), 'w') as f:
        f.write(app_build_content)
    
    # proguard-rules.pro
    with open(os.path.join(templates_dir, 'proguard-rules.pro'), 'r') as f:
        proguard_rules = f.read()
    with open(os.path.join(project_dir, 'app', 'proguard-rules.pro'), 'w') as f:
        f.write(proguard_rules)
    
    # strings.xml
    with open(os.path.join(templates_dir, 'strings.xml'), 'r') as f:
        strings = f.read()
    
    strings_content = strings.replace('{{APP_NAME}}', app_name)
    
    with open(os.path.join(project_dir, 'app', 'src', 'main', 'res', 'values', 'strings.xml'), 'w') as f:
        f.write(strings_content)
    
    # Copy uploaded image as app icon if provided
    if image_path and os.path.exists(image_path):
        # Copy to all mipmap folders
        for density in ['hdpi', 'mdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']:
            dest_path = os.path.join(project_dir, 'app', 'src', 'main', 'res', f'mipmap-{density}', 'ic_launcher.png')
            shutil.copy2(image_path, dest_path)
    
    # Create gradle wrapper files
    gradle_wrapper_dir = os.path.join(project_dir, 'gradle', 'wrapper')
    os.makedirs(gradle_wrapper_dir, exist_ok=True)
    
    # gradle-wrapper.properties
    with open(os.path.join(templates_dir, 'gradle-wrapper.properties'), 'r') as f:
        wrapper_properties = f.read()
    with open(os.path.join(gradle_wrapper_dir, 'gradle-wrapper.properties'), 'w') as f:
        f.write(wrapper_properties)
    
    # Copy gradlew files
    shutil.copy2(os.path.join(templates_dir, 'gradlew'), os.path.join(project_dir, 'gradlew'))
    shutil.copy2(os.path.join(templates_dir, 'gradlew.bat'), os.path.join(project_dir, 'gradlew.bat'))
    
    # Copy legacy build files as alternatives
    if os.path.exists(os.path.join(templates_dir, 'build_legacy.gradle')):
        shutil.copy2(os.path.join(templates_dir, 'build_legacy.gradle'), os.path.join(project_dir, 'build_legacy.gradle'))
    if os.path.exists(os.path.join(templates_dir, 'app_build_legacy.gradle')):
        shutil.copy2(os.path.join(templates_dir, 'app_build_legacy.gradle'), os.path.join(project_dir, 'app', 'build_legacy.gradle'))
    if os.path.exists(os.path.join(templates_dir, 'gradle-wrapper_legacy.properties')):
        shutil.copy2(os.path.join(templates_dir, 'gradle-wrapper_legacy.properties'), os.path.join(gradle_wrapper_dir, 'gradle-wrapper_legacy.properties'))
    
    # Make gradlew executable on Unix systems
    import stat
    gradlew_path = os.path.join(project_dir, 'gradlew')
    if os.path.exists(gradlew_path):
        st = os.stat(gradlew_path)
        os.chmod(gradlew_path, st.st_mode | stat.S_IEXEC)
    
    # settings.gradle
    settings_gradle = f'include \':app\'\nrootProject.name = "{app_name}"'
    with open(os.path.join(project_dir, 'settings.gradle'), 'w') as f:
        f.write(settings_gradle)
    
    return project_dir

@app.route('/')
def index():
    config = load_config()
    return render_template('index.html', config=config)

@app.route('/generate')
def generate_page():
    return render_template('generate.html')

@app.route('/api/config', methods=['POST'])
def save_api_config():
    config = request.json
    save_config(config)
    return jsonify({'success': True, 'message': 'Configuration saved successfully'})

@app.route('/api/test', methods=['POST'])
def test_api():
    data = request.json
    api_provider = data.get('api_provider')
    
    if api_provider == 'groq':
        api_key = data.get('groq_api_key')
        model_name = data.get('model_name', 'llama3-8b-8192')
        success, message = test_groq_api(api_key, model_name)
    elif api_provider == 'huggingface':
        api_key = data.get('huggingface_api_key')
        success, message = test_huggingface_api(api_key)
    else:
        success, message = False, 'Invalid API provider'
    
    return jsonify({'success': success, 'message': message})

@app.route('/api/generate', methods=['POST'])
def generate_app():
    try:
        prompt = request.form.get('prompt', '').strip()
        if not prompt:
            return jsonify({'success': False, 'error': 'Prompt is required'})
        
        # Handle image upload
        image_path = None
        if 'image' in request.files:
            file = request.files['image']
            if file.filename != '' and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(image_path)
        
        # Load configuration
        config = load_config()
        api_provider = config.get('api_provider', 'groq')
        
        # Generate app code
        if api_provider == 'groq':
            api_key = config.get('groq_api_key', '')
            model_name = config.get('model_name', 'llama3-8b-8192')
            if not api_key:
                return jsonify({'success': False, 'error': 'Groq API key not configured'})
            success, result = generate_with_groq(prompt, api_key, model_name)
        elif api_provider == 'huggingface':
            api_key = config.get('huggingface_api_key', '')
            if not api_key:
                return jsonify({'success': False, 'error': 'Hugging Face API key not configured'})
            success, result = generate_with_huggingface(prompt, api_key)
        else:
            return jsonify({'success': False, 'error': 'Invalid API provider'})
        
        if not success:
            return jsonify({'success': False, 'error': result})
        
        # Create Android project
        project_dir = create_android_project(result, image_path)
        
        # Create ZIP file for download
        zip_filename = f"{result.get('app_name', 'GeneratedApp')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        zip_path = os.path.join(GENERATED_FOLDER, zip_filename)
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(project_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, project_dir)
                    zipf.write(file_path, arcname)
        
        return jsonify({
            'success': True,
            'app_name': result.get('app_name', 'GeneratedApp'),
            'description': result.get('description', ''),
            'download_url': f'/download/{zip_filename}',
            'project_folder': os.path.basename(project_dir)
        })
        
    except Exception as e:
        logging.error(f"Error generating app: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/download/<filename>')
def download_file(filename):
    try:
        file_path = os.path.join(GENERATED_FOLDER, filename)
        if os.path.exists(file_path):
            return send_file(file_path, as_attachment=True)
        else:
            flash('File not found', 'error')
            return redirect(url_for('generate_page'))
    except Exception as e:
        flash(f'Error downloading file: {str(e)}', 'error')
        return redirect(url_for('generate_page'))

@app.route('/download-windows-package')
def download_windows_package():
    """Download complete Windows package"""
    try:
        package_path = 'android-app-generator-windows-20250811.zip'
        if os.path.exists(package_path):
            return send_file(package_path, as_attachment=True, download_name='android-app-generator-windows.zip')
        else:
            return jsonify({'error': 'Windows package not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def open_browser():
    """Open browser after server starts"""
    webbrowser.open('http://127.0.0.1:5001')

if __name__ == '__main__':
    # Start browser after a delay
    Timer(1.5, open_browser).start()
    # Run the app on the requested port
    app.run(host='0.0.0.0', port=5001, debug=True)
