# Android App Generator

A Flask web application that generates complete Android Studio projects from text prompts using AI APIs (Groq or Hugging Face). Upload images for custom app icons and get ready-to-import Android projects.

## Features

- 🤖 **AI-Powered Generation**: Use Groq or Hugging Face APIs to generate Android apps from natural language prompts
- 🎨 **Custom Icons**: Upload images to use as app icons in your generated projects
- 📱 **Android Studio Ready**: Generated projects are fully compatible with Android Studio
- 🌐 **Web Interface**: Easy-to-use browser-based interface
- ⚙️ **API Configuration**: Flexible API provider selection and testing
- 📦 **Complete Projects**: Download ready-to-import ZIP files with full project structure

## Installation

### Prerequisites

- Python 3.7 or later
- Internet connection for AI API calls
- Valid API keys for Groq or Hugging Face

### Quick Start

1. **Download and Extract**
   - Download the project ZIP file
   - Extract to your desired location

2. **Get API Keys**
   - **For Groq**: Visit [console.groq.com](https://console.groq.com) and create an API key
   - **For Hugging Face**: Visit [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens) and create a token

3. **Run the Application**
   - Double-click `start.bat` to launch the server
   - The browser will automatically open to http://127.0.0.1:5001
   - If the browser doesn't open automatically, navigate to the URL manually

### Manual Installation

If you prefer to run manually:

```bash
# Install dependencies
pip install flask requests werkzeug

# Run the application
python main.py
```

## Usage

### Step 1: Configure API Keys

1. Open your browser and go to http://127.0.0.1:5001
2. In the "API Configuration" section:
   - Select your preferred provider (Groq or Hugging Face)
   - Enter your API key
   - For Groq, select your preferred model
   - Click "Save Configuration"
   - Click "Test API" to verify the connection

### Step 2: Generate Android Apps

1. Click "Generate New App" button
2. Enter a detailed description of your app in the text area
3. Optionally upload an image for the app icon
4. Click "Generate App" 
5. Wait for the AI to generate your app code
6. Download the ZIP file when complete

### Step 3: Import to Android Studio

1. Extract the downloaded ZIP file
2. Open Android Studio
3. Select "Open an Existing Project"
4. Navigate to the extracted folder and select it
5. Let Android Studio sync the project
6. Build and run your app!

## Project Structure

```
android-app-generator/
├── app.py                 # Main Flask application
├── main.py               # Application entry point
├── start.bat             # Windows startup script
├── config.json           # API configuration storage
├── README.md             # This file
├── static/js/
│   └── app.js            # Frontend JavaScript
├── templates/
│   ├── index.html        # Configuration page
│   └── generate.html     # App generation page
├── android_templates/    # Android project templates
│   ├── MainActivity.java
│   ├── activity_main.xml
│   ├── AndroidManifest.xml
│   ├── build.gradle
│   ├── app_build.gradle
│   └── strings.xml
├── uploads/              # Temporary image uploads
└── generated_apps/       # Generated Android projects
```

## API Keys Setup

### Groq API (Recommended)
1. Visit [console.groq.com](https://console.groq.com)
2. Sign up for an account
3. Navigate to API Keys section
4. Create a new API key
5. Copy and paste into the application

### Hugging Face API
1. Visit [huggingface.co](https://huggingface.co)
2. Create an account and sign in
3. Go to Settings > Access Tokens
4. Create a new token with "Read" access
5. Copy and paste into the application

## Troubleshooting

### Common Issues

**Python not found error:**
- Install Python 3.7+ from [python.org](https://python.org)
- Make sure Python is added to your system PATH

**Port already in use:**
- Close any other applications using port 5001
- Or edit `main.py` to use a different port

**API test fails:**
- Verify your API key is correct
- Check your internet connection
- For Groq: ensure you have API credits available

**Generated app won't build in Android Studio:**
- Make sure you have the latest Android Studio version
- Sync the project (File > Sync Project with Gradle Files)
- Update Android SDK if prompted

## Features Explained

### AI-Powered Generation
- Converts natural language descriptions into working Android code
- Generates complete project structures ready for Android Studio
- Supports both Java and basic Material Design layouts

### Custom App Icons
- Upload any image format (PNG, JPG, JPEG, GIF, WEBP)
- Automatically resized for all Android density buckets
- Replaces default launcher icons in generated projects

### Complete Project Output
- Full Android Studio project structure
- Gradle build files configured
- AndroidManifest.xml with proper permissions
- Resource files (strings, layouts)
- MainActivity with basic functionality

## License

This project is provided as-is for educational and development purposes.
